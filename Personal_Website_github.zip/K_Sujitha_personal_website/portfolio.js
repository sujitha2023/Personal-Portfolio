var Name = document.getElementById("name");
var Email = document.getElementById("email");
var Message = document.getElementById("message");
var Subject = document.getElementById("subject");

function validateForm() {
    if (Name.value == '' || Email.value == '' ||  Subject.value == '' || Message.value == '') {
        alert("Please Fill all the Fields...");

    } else {
        alert("Message Sent Succesfully...");
    }
}